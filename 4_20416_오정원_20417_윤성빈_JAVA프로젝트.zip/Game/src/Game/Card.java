package Game;
import javax.swing.*;

public class Card
{
	public int type;
	
	public int num;
	public String path;
	public boolean isFlip = false;
	
	public JButton card = new JButton(new ImageIcon("Resource/backImage.png"));
	
	public void Flip() 
	{
		if (!isFlip) {
			card.setIcon(new ImageIcon(path));
			isFlip = true;
		}
	}
}
